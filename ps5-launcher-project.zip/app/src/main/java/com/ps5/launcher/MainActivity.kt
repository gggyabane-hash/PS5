package com.ps5.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInstaller
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.EditText
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val reqFile = 1
    private val reqApk = 2
    private val act = "com.ps5.launcher.INSTALL"

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript("window.$code", null) }
    }

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
                PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                    @Suppress("DEPRECATION")
                    val x = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                    if (x != null) startActivity(x)
                }
                PackageInstaller.STATUS_SUCCESS -> js("onInstall('ok','')")
                else -> {
                    val m = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
                    js("onInstall('err'," + JSONObject.quote(m) + ")")
                }
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(p.createIntent(), reqFile); true
                } catch (e: Exception) {
                    fileCb = null; false
                }
            }
            override fun onJsAlert(v: WebView, u: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setOnCancelListener { r.cancel() }.show()
                return true
            }
            override fun onJsConfirm(v: WebView, u: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show()
                return true
            }
            override fun onJsPrompt(v: WebView, u: String, m: String, d: String?, r: JsPromptResult): Boolean {
                val e = EditText(this@MainActivity)
                AlertDialog.Builder(this@MainActivity).setMessage(m).setView(e)
                    .setPositiveButton("OK") { _, _ -> r.confirm(e.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show()
                return true
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        val f = IntentFilter(act)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(rcv, f)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) js("onResume&&onResume()")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        js("onBack&&onBack()")
    }

    override fun onDestroy() {
        try { unregisterReceiver(rcv) } catch (e: Exception) {}
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rq == reqFile) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d))
            fileCb = null
        } else if (rq == reqApk && rs == RESULT_OK && d?.data != null) {
            install(d.data!!)
        }
    }

    private fun install(u: Uri) {
        Thread {
            try {
                val pi = packageManager.packageInstaller
                val id = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
                pi.openSession(id).use { s ->
                    contentResolver.openInputStream(u)!!.use { inp ->
                        s.openWrite("base.apk", 0, -1).use { out ->
                            inp.copyTo(out)
                            s.fsync(out)
                        }
                    }
                    val fl = PendingIntent.FLAG_UPDATE_CURRENT or
                        (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                    val pe = PendingIntent.getBroadcast(this, id, Intent(act).setPackage(packageName), fl)
                    s.commit(pe.intentSender)
                }
                js("onInstall('start','')")
            } catch (e: Exception) {
                js("onInstall('err'," + JSONObject.quote(e.message ?: "error") + ")")
            }
        }.start()
    }

    private fun icon(d: Drawable): String {
        val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, 96, 96)
        d.draw(Canvas(bmp))
        val o = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, o)
        return "data:image/png;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    inner class Bridge {
        @JavascriptInterface
        fun getApps(): String {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            for (r in pm.queryIntentActivities(q, 0)) {
                val ai = r.activityInfo.applicationInfo
                if (ai.packageName == packageName) continue
                @Suppress("DEPRECATION")
                val game = (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) ||
                    (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                arr.put(JSONObject().put("pkg", ai.packageName)
                    .put("name", r.loadLabel(pm).toString())
                    .put("game", game)
                    .put("icon", icon(r.loadIcon(pm))))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun launch(p: String) {
            val i = packageManager.getLaunchIntentForPackage(p) ?: return
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runOnUiThread { startActivity(i) }
        }

        @JavascriptInterface
        fun installApk() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
                    startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                    js("onInstall('perm','')")
                } else {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                        .addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                    startActivityForResult(i, reqApk)
                }
            }
        }
    }
}
